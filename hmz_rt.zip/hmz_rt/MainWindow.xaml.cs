﻿using System;
using System.Collections.Generic;
using System.Windows;
using MySql.Data.MySqlClient;

namespace RoomListApp
{
    public partial class MainWindow : Window
    {
        // Szoba osztály definíciója
        public class Room
        {
            public string RoomName { get; set; }
            public string Status { get; set; } // Szoba státusza most szöveges típusú

            public override string ToString()
            {
                return $"{RoomName} - {Status}";
            }
        }

        // MySQL kapcsolat beállítása
        private string connectionString = "server = localhost; database=hmz_rt;user=root;password=;sslmode=none;";

        public MainWindow()
        {
            InitializeComponent();
        }

        // A gomb eseménykezelője, ami kilistázza a szobákat
        private void btnListRooms_Click(object sender, RoutedEventArgs e)
        {
            // Szobák lista inicializálása
            List<Room> rooms = GetRoomsFromDatabase();

            // A ListBox frissítése a szobák listájával
            lstRooms.Items.Clear();
            foreach (var room in rooms)
            {
                lstRooms.Items.Add(room);
            }
        }

        // Adatok lekérése az adatbázisból
        private List<Room> GetRoomsFromDatabase()
        {
            List<Room> rooms = new List<Room>();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // SQL lekérdezés a szobák listájának lekéréséhez
                    string query = "SELECT room_number, status FROM rooms";
                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        // Szoba adatainak beolvasása
                        string roomnumber = reader.GetString("room_number");
                        string status = reader.GetString("status"); // Szoba státusza most szöveges

                        // Szoba hozzáadása a listához
                        rooms.Add(new Room
                        {
                            RoomName = roomnumber,
                            Status = status // Szoba státuszának beállítása
                        });
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hiba történt a kapcsolat során: {ex.Message}");
                }
            }

            return rooms;
        }
    }
}
