import React from 'react';
import '../styles/Modal.css';
import '../styles/Form.css';

function RegisterModal({ onClose, switchToLogin }) {
    return (
        <div className="modal-backdrop">
            <div className="modal">
                <form className="form">
                    <p className="title">Regisztráció</p>
                    <p className="message">Regisztrálj, böngéssz, foglalj és utazz szabadon!</p>

                    <div className="flex">
                        <label>
                            <input required placeholder="" type="text" className="input" />
                            <span>Családnév</span>
                        </label>

                        <label>
                            <input required placeholder="" type="text" className="input" />
                            <span>Keresznév</span>
                        </label>
                    </div>

                    <label>
                        <input required placeholder="" type="email" className="input" />
                        <span>Email</span>
                    </label>

                    <label>
                        <input required placeholder="" type="password" className="input" />
                        <span>Jelszó</span>
                    </label>

                    <label>
                        <input required placeholder="" type="password" className="input" />
                        <span>Jelszó megerősítése</span>
                    </label>

                    <button className="submit" type="submit">Regisztráció</button>
                    <p className="signin">
                        Már van egy fiókod? <a href="#" onClick={(e) => { 
                            e.preventDefault(); 
                            switchToLogin();
                        }}>Jelentkezz be!</a>
                    </p>
                </form>
                <button className="close-btn" onClick={onClose}>Bezárás</button>
            </div>
        </div>
    );
}

export default RegisterModal;
