import React, { useState } from 'react';
import '../styles/Rooms.css';

function RoomCard() {
  const [showModal, setShowModal] = useState(false);

  const room = {
    id: 1,
    image: 'https://www.peninsula.com/en/-/media/images/chicago/03roomssuitesfinal/06_premier-deluxe-suite/peninsula-chicago-deluxe-suite-bedroom-1.jpg?mw=905&hash=F441B1FC118647C2C8C81FC6002411BF',
    name: 'Deluxe Suite',
    description: 'A luxurious suite with a beautiful view of the city.',
    rating: 3.5,
    reviews: [
      'Amazing room! Very comfortable.',
      'Loved the view, but the service could be better.',
      'Perfect for a weekend getaway!',
      'Very clean, very greateful, just perfect at all, loved it so much',
      'I liked it, everyone was so kind and friendly, i can recommend it to everyone',
    ],
  };

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  return (
    <div>
      {/* Szoba kártya  */}
      <div className="card">
        <div className="first-content">
          <img src={room.image} alt={room.name} />
          <button className="expand-button" onClick={openModal}>🔍</button>
        </div>
        <div className="second-content">
          <h2>{room.name}</h2>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <img src={room.image} alt={room.name} className="modal-image" />
            <h2>{room.name}</h2>
            <p>{room.description}</p>
            <div className="rating">
              <strong>Rating:</strong> {room.rating} ⭐
            </div>
            <div className="reviews">
              <h3>User Reviews</h3>
              <ul>
                {room.reviews.map((review, index) => (
                  <li key={index}>{review}</li>
                ))}
              </ul>
            </div>
            <div className="reservation-form">
              <h3>Book Now</h3>
              <form>
                <label>
                  Name:
                  <input type="text" name="name" placeholder='Mr. Example Adam' required />
                </label>
                <label>
                  Email:
                  <input  type="email" name="email" placeholder='example@example.com' required />
                </label>
                <label>
                  Payment Method:
                  <select name="payment" required>
                    <option value="credit-card">Credit Card</option>
                    <option value="paypal">PayPal</option>
                    <option value="cash">Cash at the register</option>
                  </select>
                </label>
                <button type="submit">Reserve</button>
              </form>
            </div>
            <button className="close-button" onClick={closeModal}>❌ Close</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default RoomCard;
