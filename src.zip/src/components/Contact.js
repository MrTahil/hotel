import React from 'react';
import '../styles/Contact.css';

function Contact() {
    return (
        <section className="contact">
            <h2>Kapcsolat</h2>
            <p>Vedd fel velünk a kapcsolatot bármikor!</p>
            <p>Email: info@szalloda.hu</p>
            <p>Telefon: +36 30 123 4567</p>
            <a href="mailto:info@szalloda.hu" className="cta-button">Írj nekünk</a>
        </section>
    );
}

export default Contact;
