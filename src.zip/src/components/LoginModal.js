import React from 'react';
import '../styles/Modal.css';

function LoginModal({ onClose, switchToRegister }) {
    return (
        <div className="modal-backdrop">
            <div className="modal">
                <h2 className='title'>Bejelentkezés</h2>
                <p className="message">Jelentkezz be, böngéssz, foglalj és utazz szabadon!</p>
                <form>
                    <label>
                        <span>Email</span>
                        <input type="email" required />
                    </label>
                    <label>
                        <span>Jelszó</span>
                        <input type="password" required />
                    </label>
                    <button type="submit">Bejelentkezés</button>
                    <p className="signin">
                        Nincs fiókod? <a href="#" onClick={(e) => { 
                            e.preventDefault(); 
                            switchToRegister();
                        }}>Regisztrálj!</a>
                    </p>
                </form>
                <button className="close-btn" onClick={onClose}>Bezárás</button>
            </div>
        </div>
    );
}

export default LoginModal;
