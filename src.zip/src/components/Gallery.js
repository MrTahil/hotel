import React from 'react';
import '../styles/Gallery.css';

function Gallery() {
    const images = [
        'https://picsum.photos/id/237/200/300',
        'https://picsum.photos/id/237/200/300',
        'https://picsum.photos/id/237/200/600',
        'https://via.placeholder.com/300x200?text=Kép+4',
        'https://via.placeholder.com/300x200?text=Kép+5',
        'https://via.placeholder.com/300x200?text=Kép+6',
    ];

    return (
        <section className="gallery">
            <h2>Galéria</h2>
            <div className="gallery-images">
                {images.map((image, index) => (
                    <div className="image-item" key={index}>
                        <img src={image} alt={`Galéria kép ${index + 1}`} />
                    </div>
                ))}
            </div>
        </section>
    );
}

export default Gallery;
